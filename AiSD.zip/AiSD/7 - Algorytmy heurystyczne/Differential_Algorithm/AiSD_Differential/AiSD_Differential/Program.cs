﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AiSD_Differential
{
    class Program
    {
        static void Main(string[] args)
        {
            doDiff(Jong, 6, 1, 0.5, -5, 5, 1000);
            doDiff(Jong, 6, 1, 0.5, -5, 5, 1000);
            Minimalizajca(StyblinskiTang, StyblinskiTangTab, -10, 10, 1000000, 0.00001, 10);
            Minimalizajca(Sphare2, DSphare2, -10, 10, 1000000, 0.00001, 10);

            doDiff(Jong, 6, 1, 0.5, -5, 5, 1000);

        }








        #region optymalizacja gradientowa
        public static void Minimalizajca(Func<double, double, double> f, Func<double, double, double[]> tabf, double min, double max, int t, double step, int attemps)
        {
            Random random = new Random();

            double fmin = double.MaxValue;
            double fcmin = double.MaxValue;
            double x;
            double y;
            double[] fparams = new double[2];
            double[] fcparams = new double[2];
            double fval;
            double[] tabfval;
            double fnval;

            for (int i = 0; i < attemps; i++)
            {
                x = random.NextDouble() * (max - min) + min;
                y = random.NextDouble() * (max - min) + min;

                for (int j = 0; j < t; j++)
                {
                    fval = f(x, y);
                    tabfval = tabf(x, y);
                    fnval = f(x - step * tabfval[0], y - step * tabfval[1]);

                    if (fval > fnval)
                    {
                        x -= (step * tabfval[0]);
                        y -= (step * tabfval[1]);
                        fcmin = fval;
                        fcparams[0] = x;
                        fcparams[1] = y;
                    }
                    else
                    {
                        break;
                    }

                }

                if (fcmin < fmin)
                {
                    fmin = fcmin;
                    fparams[0] = fcparams[0];
                    fparams[1] = fcparams[1];
                }


            }

            Console.WriteLine(string.Join(" | ", fparams));
            Console.WriteLine(fmin);

        }
        #endregion









        #region funkcje
        public static double StyblinskiTang(double x, double y)
        {
            return 0.5 * (Math.Pow(y,4) - 16 * y * y + 5 * y + Math.Pow(x, 4) - 16 * x * x + 5 * x);
        }

        public static double[] StyblinskiTangTab(double x, double y)
        {
            double[] d = new double[2];

            d[0] = 0.5 * (4 * Math.Pow(x, 3) - 32 * x + 5);
            d[1] = 0.5 * (4 * Math.Pow(y, 3) - 32 * y + 5);

            return d;
        }

        public static double Sphare2(double x, double y)
        {
            return x * x + y * y;
        }

        public static double[] DSphare2(double x, double y)
        {
            double[] d = new double[2];

            d[0] = 2 * x;
            d[1] = 2 * y;

            return d;
        }

        public static double Jong(double x, double y, double z)
        {
            return x * x + y * y + z * z;
        }

        public static double JongPrzystosowanie(double x, double y, double z)
        {
            return 75 - Jong(x, y, z);
        }
        #endregion











        #region Algorytm
        public static void doDiff(Func<double, double, double, double> f, int NP, double F, double CR, double min, double max, int attemps)
        {
            Random random = new Random();

            List<double[]> X = new List<double[]>();
            List<double[]> V = new List<double[]>();
            List<double[]> U = new List<double[]>();

            for (int i = 0; i < NP; i++)
            {
                double[] nv = new double[3];

                for (int j = 0; j < 3; j++)
                {
                    nv[j] = random.NextDouble() * (max - min) + min;
                }
                X.Add(nv);
            }

            for (int p = 0; p < attemps; p++)
            {

                for (int i = 0; i < X.Count; i++)
                {
                    double[] nv = new double[3];
                    List<int> r = new List<int>
                {
                    i
                };

                    while (r.Count != 3)
                    {
                        int a = random.Next(0, NP);
                        if (!r.Contains(a))
                        {
                            r.Add(a);
                        }
                    }

                    for (int j = 0; j < 3; j++)
                    {
                        nv[j] = X[i][j] + F * (X[r[1]][j] - X[r[2]][j]);
                    }

                    V.Add(nv);
                }

                for (int i = 0; i < X.Count; i++)
                {
                    double[] nv = new double[3];

                    int d = random.Next(0, 3);
                    for (int j = 0; j < 3; j++)
                    {
                        if (random.NextDouble() < CR || d == j)
                        {
                            nv[j] = X[i][j];
                        }
                        else
                        {
                            nv[j] = V[i][j];
                        }
                    }

                    U.Add(nv);
                }

                for (int i = 0; i < X.Count; i++)
                {
                    if (f(X[i][0], X[i][1], X[i][2]) < f(U[i][0], U[i][1], U[i][2]))
                    {
                        X[i] = U[i];
                    }
                }

                V.Clear();
                U.Clear();
            }


            int indexMin = 0;
            for (int i = 1; i < X.Count; i++)
            {
                if (f(X.ElementAt(i)[0], X.ElementAt(i)[1], X.ElementAt(i)[2]) > f(X.ElementAt(indexMin)[0], X.ElementAt(indexMin)[1], X.ElementAt(indexMin)[2]))
                {
                    indexMin = i;
                }
            }


            Console.WriteLine(f(X.ElementAt(indexMin)[0], X.ElementAt(indexMin)[1], X.ElementAt(indexMin)[2]));
            Console.WriteLine(string.Join(" | ", X.ElementAt(indexMin)));
        }
        #endregion
    }
}
