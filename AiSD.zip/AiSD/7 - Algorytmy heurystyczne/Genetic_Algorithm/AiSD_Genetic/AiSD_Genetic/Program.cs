﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AiSD_Genetic
{
    class Program
    {

        static void Main(string[] args)
        {

            doGenetic(Jong, JongPrzystosowanie, 6, 0.1, -5, 5, 300000);
            doGenetic(Jong, JongPrzystosowanie, 6, 0.1, -5, 5, 300000);

            Minimalizajca(StyblinskiTang, StyblinskiTangTab, -10, 10, 1000000, 0.00001, 10);
            Minimalizajca(Sphare2, DSphare2, -10, 10, 1000000, 0.00001, 10);

            doGenetic(Jong, JongPrzystosowanie, 6, 0.1, -5, 5, 300000);
        }











        #region funkcje
        public static double StyblinskiTang(double x, double y)
        {
            return 0.5 * (Math.Pow(y, 4) - 16 * y * y + 5 * y + Math.Pow(x, 4) - 16 * x * x + 5 * x);
        }

        public static double[] StyblinskiTangTab(double x, double y)
        {
            double[] d = new double[2];

            d[0] = 0.5 * (4 * Math.Pow(x, 3) - 32 * x + 5);
            d[1] = 0.5 * (4 * Math.Pow(y, 3) - 32 * y + 5);

            return d;
        }

        public static double Sphare2(double x, double y)
        {
            return x * x + y * y;
        }

        public static double[] DSphare2(double x, double y)
        {
            double[] d = new double[2];

            d[0] = 2 * x;
            d[1] = 2 * y;

            return d;
        }

        public static double Jong(double x, double y, double z)
        {
            return x * x + y * y + z * z;
        }

        public static double JongPrzystosowanie(double x, double y, double z)
        {
            return 75 - Jong(x, y, z);
        }
        #endregion








        #region optymalizacja gradientowa
        public static void Minimalizajca(Func<double, double, double> f, Func<double, double, double[]> tabf, double min, double max, int t, double step, int attemps)
        {
            Random random = new Random();

            double fmin = double.MaxValue;
            double fcmin = double.MaxValue;
            double x;
            double y;
            double[] fparams = new double[2];
            double[] fcparams = new double[2];
            double fval;
            double[] tabfval;
            double fnval;

            for (int i = 0; i < attemps; i++)
            {
                x = random.NextDouble() * (max - min) + min;
                y = random.NextDouble() * (max - min) + min;

                for (int j = 0; j < t; j++)
                {
                    fval = f(x, y);
                    tabfval = tabf(x, y);
                    fnval = f(x - step * tabfval[0], y - step * tabfval[1]);

                    if (fval > fnval)
                    {
                        x -= (step * tabfval[0]);
                        y -= (step * tabfval[1]);
                        fcmin = fval;
                        fcparams[0] = x;
                        fcparams[1] = y;
                    }
                    else
                    {
                        break;
                    }

                }

                if (fcmin < fmin)
                {
                    fmin = fcmin;
                    fparams[0] = fcparams[0];
                    fparams[1] = fcparams[1];
                }


            }

            Console.WriteLine(string.Join(" | ", fparams));
            Console.WriteLine(fmin);

        }
        #endregion











        #region Algorytm
        public static void doGenetic(Func<double, double, double, double> f, Func<double, double, double, double> fp, int popSize, double propMut, double min, double max, int attemps)
        {
            Random random = new Random();

            List<double[]> v = new List<double[]>();
            List<double[]> buff = new List<double[]>();

            for (int i = 0; i < popSize; i++)
            {
                double[] nv = new double[3];

                for (int j = 0; j < 3; j++)
                {
                    nv[j] = random.NextDouble() * (max - min) + min;
                }
                v.Add(nv);
            }


            double splitSizeMax = 1.0 / popSize + (2.0 / 100) * popSize;
            double splitSizeMin = 1.0 / popSize - (2.0 / 100) * popSize;

            double[] splits = new double[popSize];
            splits[0] = random.NextDouble() * (splitSizeMax - splitSizeMin) + splitSizeMin;
            splits[popSize - 1] = 1;
            for (int i = 1; i < popSize - 1; i++)
            {
                splits[i] = splits[i - 1] + random.NextDouble() * (splitSizeMax - splitSizeMin) + splitSizeMin;
            }

            for (int k = 0; k < attemps; k++)
            {
                for (int p = 0; p < popSize / 2; p++)
                {

                    double r1 = random.NextDouble();
                    double r2 = random.NextDouble();
                    int r1Index = 0, r2Index = 0;

                    for (int i = 0; i < popSize; i++)
                    {
                        if (splits[i] > r1)
                        {
                            r1Index = i;
                            break;
                        }
                    }

                    for (int i = 0; i < popSize; i++)
                    {
                        if (splits[i] > r2)
                        {
                            r2Index = i;
                            break;
                        }
                    }


                    double[] rr1 = v.ElementAt(r1Index);
                    double[] rr2 = v.ElementAt(r2Index);

                    for (int i = 0; i < 3; i++)
                    {
                        if (random.NextDouble() < propMut)
                        {
                            rr1[i] += (random.NextDouble() - 0.5);
                        }
                    }

                    for (int i = 0; i < 3; i++)
                    {
                        if (random.NextDouble() < propMut)
                        {
                            rr2[i] += (random.NextDouble() - 0.5);
                        }
                    }

                    double n = random.NextDouble();

                    double[] kid1 = new double[3];
                    for (int i = 0; i < 3; i++)
                    {
                        kid1[i] = rr1[i] + (n * (rr2[i] - rr1[i]));
                    }

                    double[] kid2 = new double[3];
                    for (int i = 0; i < 3; i++)
                    {
                        kid2[i] = rr2[i] + (n * (rr1[i] - rr2[i]));
                    }

                    if (fp(rr1[0], rr1[1], rr1[2]) > fp(kid1[0], kid1[1], kid1[2]))
                    {
                        buff.Add(rr1);
                    }
                    else
                    {
                        buff.Add(kid1);
                    }

                    if (fp(rr2[0], rr2[1], rr2[2]) > fp(kid2[0], kid2[1], kid2[2]))
                    {
                        buff.Add(rr2);
                    }
                    else
                    {
                        buff.Add(kid2);
                    }

                }

                v.Clear();
                for (int i = 0; i < buff.Count; i++)
                {
                    v.Add(buff.ElementAt(i));

                }
                buff.Clear();
            }

            int indexMin = 0;
            for (int i = 1; i < v.Count; i++)
            {
                if (fp(v.ElementAt(i)[0], v.ElementAt(i)[1], v.ElementAt(i)[2]) > fp(v.ElementAt(indexMin)[0], v.ElementAt(indexMin)[1], v.ElementAt(indexMin)[2]))
                {
                    indexMin = i;
                }
            }

            Console.WriteLine(f(v.ElementAt(indexMin)[0], v.ElementAt(indexMin)[1], v.ElementAt(indexMin)[2]));
            Console.WriteLine(string.Join(" | ", v.ElementAt(indexMin)));
        }
        #endregion
    }
}
