﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AiSD_Knuth_Morris_Pratt
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(doKMP("ala ma kota", "kot"));
            Console.WriteLine(doKMP("ala nie ma kota tylko psa", "kot"));
        }

        

        static public int doKMP(string s, string p)
        {
            int[] tab = Prefiks(p);

            int m = p.Length;

            if (m == 0)
                return -1;

            for (int i = 0, k = 0; i < s.Length; i++)
            {
                while (k!=int.MaxValue)
                {
                    if (p[k] == s[i])
                    {
                        if (++k == m)
                        {
                            return i + 1 - m;
                        }
                        break;
                    }
                    if (k == 0)
                    {
                        break;
                    }
                    k = tab[k - 1];
                }
            }

            return -1;
        }

        private static int[] Prefiks(string w)
        {
            int[] tab = new int[w.Length];

            tab[0] = 0;
            int k = 0;

            for (int i = 1; i < tab.Length; i++)
            {
                while (k > 0 && w[k] != w[i])
                    k = tab[k - 1];

                if (w[i] == w[k])
                    k++;

                tab[i] = k;
            }

            return tab;
        }
    }
}
