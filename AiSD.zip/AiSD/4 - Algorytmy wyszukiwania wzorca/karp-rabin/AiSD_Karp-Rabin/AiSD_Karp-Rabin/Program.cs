﻿using System;
using System.Collections.Generic;

namespace AiSD_Karp_Rabin

{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine(string.Join(", ", doKR("ala ma kota", "kot").ToArray()));
            Console.WriteLine(string.Join(", ", doKR("ala ma psa a nie kota", "kot").ToArray()));
        }


        public static List<int> doKR(string w, string p, int q = 11)
        {

            int d = 256;
            List<int> listek = new List<int>();
            int M = p.Length, N = w.Length;
            int pv = 0, wv = 0, h = 1;


            for (int i = 0; i < M - 1; i++) 
            {
                h = (h * d) % q;
            }

            for (int i = 0; i < M; i++)
            {
                pv = (d * pv + p[i]) % q;
                wv = (d * wv + w[i]) % q;
            }

            for (int i = 0; i <= N - M; i++) 
            {
                if (pv == wv)
                {
                    int j = 0;
                    for (; j < M; j++)
                    {
                        if (w[i + j] != p[j])
                            break;
                    }

                    if (j == M)
                        listek.Add(i);

                }

                if (i < N - M) 
                {
                    wv = (d * (wv - w[i] * h) + w[i + M]) % q;
                    if (wv < 0)
                        wv += q;
                }
            }
            return listek;
        }

    }
}
