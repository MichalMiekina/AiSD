﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AiSD_Dijkstra.zadanie
{
    class Dijkstra33
    {
        #region Tworzenie parametrów
        public double[,] Graph { get; set; }
        public double[] Droga { get; set; }
        public int[] Poprzednik { get; set; }
        public List<int> Q { get; set; }
        public List<int> S { get; set; }
        #endregion

        #region Tworzenie obiektu grafu
        public Dijkstra33(double[,] graph)
        {
            Graph = graph;

            Droga = new double[graph.GetLength(0)];
            Poprzednik = new int[graph.GetLength(0)];
            Q = new List<int>();
            S = new List<int>();

            for (int i = 0; i < Droga.Length; i++)
            {
                Droga[i] = Double.PositiveInfinity;
            }
            for (int i = 0; i < Poprzednik.Length; i++)
            {
                Poprzednik[i] = -1;
            }

            for(int i = 0; i < graph.GetLength(0); i++)
            {
                Q.Add(i);
            }
        }
        #endregion

        #region tworzenie d(u) i p(u)
        public void doDijkstra(int start, int target)
        {
            Droga[start] = 0;

            while (Q.Count != 0)
            {
                double tmpMin = Droga[Q[0]];
                for(int i = 0; i < Droga.Length; i++)
                {
                    if (Droga[i] < tmpMin && Q.Contains(i))
                        tmpMin = Droga[i];
                }
                for(int u = 0; u < Droga.Length; u++)
                {
                    if (tmpMin == Droga[u])
                    {
                        for(int j = 0; j < Q.Count; j++)
                        {
                            if (Q[j].ToString() == u.ToString())
                            {
                                S.Add(Q[j]);
                                Q.RemoveAt(j);
                                
                                for(int w = 0; w < Graph.GetLength(1); w++)
                                {
                                    if(Graph[S[S.Count-1],w]!=double.PositiveInfinity && Q.Contains(w))
                                    {
                                        if (Droga[w] > Droga[u] + Graph[u, w])
                                        {
                                            Droga[w] = Droga[u] + Graph[u, w];
                                            Poprzednik[w] = u;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for(int i = 0; i < Droga.Length; i++)
            {
                Console.WriteLine(Droga[i]);
                Console.WriteLine(Poprzednik[i]);
            }
            


        }
        #endregion
    }
}
