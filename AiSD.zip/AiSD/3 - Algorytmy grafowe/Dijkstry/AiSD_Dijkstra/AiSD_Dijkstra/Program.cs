﻿using System;
using AiSD_Dijkstra.zadanie;

namespace AiSD_Dijkstra
{
    class Program
    {
        static void Main(string[] args)
        {
            double[,] graf1 = new double[6, 6];
            for(int x = 0; x < graf1.GetLength(0); x++)
            {
                for (int y = 0; y < graf1.GetLength(1); y++)
                {
                    graf1[x, y] = double.PositiveInfinity;
                }
            }
            
            graf1[0, 1] = 3;
            graf1[0, 4] = 3;
            graf1[1, 2] = 1;
            graf1[2, 3] = 3;
            graf1[2, 5] = 1;
            graf1[3, 1] = 3;
            graf1[4, 5] = 2;
            graf1[5, 0] = 6;
            graf1[5, 3] = 1;

            Dijkstra33 graf = new Dijkstra33(graf1);
            graf.doDijkstra(0, 4);

        }
    }
}
