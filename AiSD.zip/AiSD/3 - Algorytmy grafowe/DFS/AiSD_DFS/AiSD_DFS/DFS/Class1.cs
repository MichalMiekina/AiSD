﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Text;

namespace AiSD_DFS.DFS
{
    class Graph
    {
        public int[,] graph { get; set; }
        public List<bool> visited  { get; set;}
        public List<bool> discovered { get; set; }
        public int _currentPoint { get; set; }
        public int _visitedAmount { get; set; }
        public int movesCounter { get; set; }

        public Graph(int [,] graph)
        {
            this.graph = graph;
            visited = new List<bool>();
            discovered = new List<bool>();

            for (int i = 0; i < graph.GetLength(0); i++)
                visited.Add(false);


            for (int i = 0; i < graph.GetLength(0); i++)
                discovered.Add(false);



            _currentPoint = 0;
            _visitedAmount = 0;

        }

        public void doDFS()
        {
            discovered[0] = true;
            while (_visitedAmount != visited.Count)
            {
                goNewPoint();
            }
            Console.Write("graf sprawdzony");
        }
            
        public void goLastPoint()
        {
            for(int i = 0; i < graph.GetLength(0); i++)
            {
                if (visited[i] == false && discovered[i] == true)
                {
                    visited[i] = true;
                    _visitedAmount++;
                    _currentPoint = i;
                    break;
                }
                    
            }
        }

        public void goNewPoint()
        {
            for (int i = 0; i < graph.GetLength(0); i++)
            {
                if (visited[i] == false && discovered[i] == false)
                {
                    discovered[i] = true;
                    _currentPoint = i;
                    break;
                }
            }
            goLastPoint();
        }
    }
}
