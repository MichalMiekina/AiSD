﻿using System;
using AiSD_DFS.DFS;

namespace AiSD_DFS
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            int[,] graph = new int[7,7]
            {
               {0,1,1,1,0,0,0 },
               {0,1,1,1,0,0,0 },
               {0,1,1,1,0,0,0 },
               {0,1,1,1,0,0,0 },
               {0,1,1,1,0,0,0 },
               {0,1,1,1,0,0,0 },
               {0,1,1,1,0,0,0 }
            };
            */

            int[,] graph = new int[4, 4]
            {
                /*
                {-1, 1, 1,-1 },
                { 1,-1, 1,-1 },
                { 1, 1,-1, 1 },
                {-1,-1, 1,-1 }
                */
                {0,1,1,0 },
                {1,0,1,0 },
                {1,1,0,1 },
                {0,0,1,0 }
            };


            Graph graph1 = new Graph(graph);
            //Console.WriteLine(graph1._currentPoint);
            graph1.doDFS();
        }
    }
}
