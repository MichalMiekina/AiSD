﻿using System;

namespace AiSD_kolejkaPriorytetowa
{
    class Program
    {
        static void Main(string[] args)
        {
            Kolejka a = new Kolejka(3);
            a.dodaj();
            Console.WriteLine(a.odczyt());
            a.dodaj();
            Console.WriteLine(a.odczyt());
            a.dodaj();
            Console.WriteLine(a.odczyt());
            a.usun();
            a.usun();
            a.dodaj();
            Console.WriteLine(a.odczyt());

            if (a.czyPusta()) Console.WriteLine("pusta");
            else Console.WriteLine("nie pusta");

            a.usun();

            Console.WriteLine(a.odczyt());
            if (a.czyPusta()) Console.WriteLine("pusta");
            else Console.WriteLine("nie pusta");

            a.usun();

            Console.WriteLine(a.odczyt());
            if (a.czyPusta()) Console.WriteLine("pusta");
            else Console.WriteLine("nie pusta");

        }
    }

    class Kolejka
    {
        protected Klient[] kolejka;
        protected int poczatek_kolejki;
        protected int koniec_kolejki;
        protected int ilosc_el_kolejki;

        public Kolejka(int size)
        {
            kolejka = new Klient[size];
            poczatek_kolejki = 0;
            koniec_kolejki = 0;
            ilosc_el_kolejki = 0;
        }

        

        public void dodaj()
        {
            if (ilosc_el_kolejki < kolejka.Length)
            {
                Console.Write("Podaj element do kolejki: ");
                int value = Convert.ToInt16(Console.ReadLine());
                Console.Write("Podaj priorytet elementu do kolejki: ");
                int prio = Convert.ToInt16(Console.ReadLine());
                
                if (czyPusta())
                {
                    kolejka[koniec_kolejki] = new Klient(prio, value);
                }
                else
                {
                    int book;
                    
                    for (int i = koniec_kolejki - 1; ; i--)
                    {
                        if (i < 0)
                        {
                            i = kolejka.Length - 1;
                        }


                        if (kolejka[i].getPrio() >= prio)
                        {
                            
                            book = koniec_kolejki;
                            break;
                            
                        }


                        if (i == poczatek_kolejki)
                        {
                            book = i;
                            break;
                        }
                    }

                    if (book > kolejka.Length - 1)
                        book = 0;

                    for (int i = koniec_kolejki; ; i--)
                    {
                        if (i == book)
                        {
                            kolejka[i] = new Klient(prio, value);
                            break;
                        }
                        if (i < 0)
                        {
                            i = kolejka.Length - 1;

                        }
                        if (i == kolejka.Length - 1)
                        {
                            kolejka[0] = kolejka[i];
                        }
                        else
                        {
                            kolejka[i + 1] = kolejka[i];
                        }
                        
                    }
                }

                koniec_kolejki++;
                ilosc_el_kolejki++;
                if (koniec_kolejki > kolejka.Length - 1)
                    koniec_kolejki = 0;
            }
            else
                Console.WriteLine("Kolejka jest zapelniona");
        }



        public void usun()
        {
            if (ilosc_el_kolejki > 0)
            {
                ilosc_el_kolejki--;
                if (poczatek_kolejki == kolejka.Length - 1)
                {
                    poczatek_kolejki = 0;
                }
                else
                {
                    poczatek_kolejki++;
                }
            }
        }

        public bool czyPusta()
        {
            if (ilosc_el_kolejki == 0) return true;
            else return false;
        }

        public int odczyt()
        {
            if (!czyPusta())
            {
                Console.WriteLine("indeks odczytu: " + poczatek_kolejki);
                return kolejka[poczatek_kolejki].getValue();
            }
            else
            {
                Console.WriteLine("Nie mozna odczytac z kolejki, jest pusta!");
                return 0;
            }
        }
    }

    class Klient
    {
        protected int prio;
        protected int value;

        public Klient()
        {
            prio = 0;
            value = 1;
        }

        public Klient(int prio,int value)
        {
            this.prio = prio;
            this.value = value;
        }

        public int getPrio()
        {
            return prio;
        }

        public int getValue()
        {
            return value;
        }

        public void setPrio(int prio)
        {
            this.prio = prio;
        }

        public void setValue(int value)
        {
            this.value = value;
        }
    }
}

