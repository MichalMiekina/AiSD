﻿using System;

namespace AiSD_stos
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] stos = new int[4];
            int stpr = 0;
        }

        bool ifEmpty(int stpr)
        {
            if (stpr == 0)
                return true; 
            else
                return false;
        }

        int odczyt(int[] stos,int stpr)
        {
            return stos[stpr-1];
        }

        void dodaj(int[] stos,int stpr,int value)
        {
            if (stpr != stos.Length)
            {
                stos[stpr] = value;
                stpr++;
            }
            else
                Console.WriteLine("Stos jest pełny!");
            
        }

        void usun(int stpr)
        {
            stpr--;
        }
    }
}
