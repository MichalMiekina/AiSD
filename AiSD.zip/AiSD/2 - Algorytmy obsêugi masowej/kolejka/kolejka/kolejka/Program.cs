﻿using System;
using System.Collections.Generic;

namespace kolejka
{
    class Program
    {
        static void Main(string[] args)
        {
            Kolejka a = new Kolejka(3);
            a.dodaj();
            Console.WriteLine(a.odczyt());
            a.dodaj();
            a.dodaj();
            Console.WriteLine(a.odczyt());
            a.usun();
            Console.WriteLine(a.odczyt());
            a.usun();
            Console.WriteLine(a.odczyt());
            a.dodaj();
            a.dodaj();
            a.usun();
            a.usun();
            Console.WriteLine(a.odczyt());

            if (a.czyPusta()) Console.WriteLine("pusta");
            else Console.WriteLine("nie pusta");

            a.usun();

            Console.WriteLine(a.odczyt());
            if (a.czyPusta()) Console.WriteLine("pusta");
            else Console.WriteLine("nie pusta");

            a.usun();

            Console.WriteLine(a.odczyt());
            if (a.czyPusta()) Console.WriteLine("pusta");
            else Console.WriteLine("nie pusta");

        }
    }

    class Kolejka
    {
        protected int[] kolejka;
        protected int poczatek_kolejki;
        protected int koniec_kolejki;
        protected int ilosc_el_kolejki;

        public Kolejka(int size)
        {
            kolejka = new int[size];
            poczatek_kolejki = 0;
            koniec_kolejki = 0;
            ilosc_el_kolejki = 0;
        }

        public void dodaj()
        {
            if (ilosc_el_kolejki < kolejka.Length)
            {
                Console.Write("Podaj element do kolejki: ");
                kolejka[koniec_kolejki] = Convert.ToInt16(Console.ReadLine());
                koniec_kolejki++;
                ilosc_el_kolejki++;
                if (koniec_kolejki > kolejka.Length - 1)
                    koniec_kolejki = 0;
            }
        }

        public void usun()
        {
            if (ilosc_el_kolejki > 0)
            {
                ilosc_el_kolejki--;
                if (poczatek_kolejki == kolejka.Length - 1)
                {
                    poczatek_kolejki = 0;
                }
                else
                {
                    poczatek_kolejki++;
                }
            }
        }

        public bool czyPusta()
        {
            if (ilosc_el_kolejki == 0) return true;
            else return false;
        }

        public int odczyt()
        {
            if (!czyPusta())
            {
                return kolejka[poczatek_kolejki];
            }
            else
            {
                Console.WriteLine("Nie mozna odczytac z kolejki, jest pusta!");
                return 0;
            }
        }
    }
}
